import pygame
import random
import math
from pygame import mixer

mixer.init()
pygame.init()

mixer.music.load('background.wav')
mixer.music.play(-1)

screen = pygame.display.set_mode((800,600))
pygame.display.set_caption('Space shooter game')
icon=pygame.image.load('icon.png')
pygame.display.set_icon(icon)

background=pygame.image.load('bg.png')

spaceshipimg=pygame.image.load('spaceship.png')

alienimg=[]
alienX=[]
alienY=[]
alienspeedX=[]
alienspeedY=[]

no_of_aliens=12

for i in range(no_of_aliens):

    alienimg.append(pygame.image.load('enemy03.png'))
    alienX.append(random.randint(0,736))
    alienY.append(random.randint(30,150))
    alienspeedX.append(1)
    alienspeedY.append(20)

score=0
level=1
level_up_score=10

bulletimg=pygame.image.load('bullet.png')
check=False
bulletX=370
bulletY=480


spaceshipX=370
spaceshipY=480
changX=0 
running=True

font=pygame.font.SysFont('Arial',20,'bold')
font_gameover = pygame.font.SysFont('Arial', 64, 'bold')
font_level_up = pygame.font.SysFont('Arial', 50, 'bold')

def score_text():
    img=font.render(f'Score: {score} Level: {level}',True,'White')
    screen.blit(img,(10,10))


def gameover():
    img_gameover=font_gameover.render('GAME OVER', True,'White')
    screen.blit(img_gameover, (200, 250))

# add level up
def level_up_text():
    img_level_up = font_level_up.render(f'Level {level}!', True, 'white')
    screen.blit(img_level_up, (300, 250))

while running:
    screen.blit(background, (0,0))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            running=False

        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                changX=-3
            if event.key==pygame.K_RIGHT:
                changX=3
            if event.key==pygame.K_SPACE:
                if check is False:
                    bulletsound=mixer.Sound('laser.wav')
                    bulletsound.play()
                    check=True
                    bulletX=spaceshipX

        if event.type==pygame.KEYUP:
            changX=0

    spaceshipX+=changX

    if spaceshipX<=0:
        spaceshipX=0
    elif spaceshipX>=765:
        spaceshipX=765

    for i in range(no_of_aliens):
        if alienY[i] > 420:
           for j in range(no_of_aliens):
            alienY[j] = 1000
           gameover()
           break
        alienX[i]+=alienspeedX[i]
        if alienX[i]<=0:
            alienspeedX[i] = level
            alienY[i]+=alienspeedY[i]
        if alienX[i]>=765:
            alienspeedX[i]=-level
            alienY[i]+=alienspeedY[i]
        
        distance=math.sqrt(math.pow(bulletX-alienX[i],2)+math.pow(bulletY-alienY[i],2))
        if distance < 27:
            explosionsound=mixer.Sound('explosion.wav')
            explosionsound.play()
            bulletY = 480
            check = False
            alienX[i]=random.randint(0,736)
            alienY[i]=random.randint(30,150)
            score += 1
            #add level up
            if score % level_up_score == 0 and level < 7:
                level += 1
                level_up_text()
                pygame.display.update()
                pygame.time.delay(2000)

        screen.blit(alienimg[i], (alienX[i], alienY[i]))

    if bulletY<=0:
        bulletY=480
        check=False

    if check:
        screen.blit(bulletimg,(bulletX, bulletY))
        bulletY-=5

   

    

    screen.blit(spaceshipimg,(spaceshipX, spaceshipY))
    
    score_text()
    pygame.display.update()
